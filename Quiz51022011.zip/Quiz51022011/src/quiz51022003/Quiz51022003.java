/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quiz51022003;


/**
 *
 * @author Asus
 */
public class Quiz51022003 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        new Menu();
    }
}
